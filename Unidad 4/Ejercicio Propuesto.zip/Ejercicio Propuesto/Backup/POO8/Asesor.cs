﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POO8
{
    class Asesor : Alumno
    {
        string _nombre;
        int _edad;
        char _sexo;
        string _nomMat;

        public string RetNomAsesAlu()
        {
            return _nombre + " , " + base._nombre + " , " +base._noCon;
        }
        public void Leer(DataGridView dGV1, DataGridView dGV2)
        {
            _nombre = dGV2[0, 0].Value.ToString();
            _edad = Convert.ToInt32(dGV2[1, 0].Value);
            _sexo = Convert.ToChar(dGV2[2, 0].Value);
            _nomMat = dGV2[3, 0].Value.ToString();
            base.Leer(dGV1);
        }
        public void Visua(DataGridView dGV1, DataGridView dGV2)
        {
            dGV2[0, 0].Value = _nombre;
            dGV2[1, 0].Value = _edad.ToString();
            dGV2[2, 0].Value = _sexo.ToString();
            dGV2[3, 0].Value = _nomMat;
            base.Visua(dGV1);
        }
    }
}
