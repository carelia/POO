﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POO8
{
    public partial class Form1 : Form
    {
        Alumno oAlu = new Alumno();
        Profesor oProf = new Profesor();
        Empleado oEmp = new Empleado();
        Asesor oAses = new Asesor();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                oAlu.Leer(dataGridView1);
            else if (radioButton2.Checked)
                oProf.Leer(dataGridView1);
            else if (radioButton3.Checked)
                oEmp.Leer(dataGridView1);
            else
                oAses.Leer(dataGridView1, dataGridView3);
        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label1.Text = "ALUMNO";
                label2.Text = "ALUMNO";
            }
            else if (radioButton2.Checked)
            {
                label1.Text = "PROFESOR";
                label2.Text = "PROFESOR";
            }
            else
            {
                label1.Text = "EMPLEADO";
                label2.Text = "EMPLEADO";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                oAlu.Visua(dataGridView2);
            else if (radioButton2.Checked)
                oProf.Visua(dataGridView2);
            else if (radioButton3.Checked)
                oEmp.Visua(dataGridView2);
            else
                oAses.Visua(dataGridView2, dataGridView4);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView2.Rows.Add();
            dataGridView4.Rows.Add();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                label3.Text = "LA MITAD DE LA EDAD DEL ALUMNO ES = " + oAlu.MitadEdad.ToString();
            else if(radioButton2.Checked)
                label3.Text = "LA MITAD DE LA EDAD DEL PROFESOR ES = " + oProf.MitadEdad.ToString();
            else
                label3.Text = "LA MITAD DE LA EDAD DEL EMPLEADO ES = " + oEmp.MitadEdad.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label4.Text = oAses.RetNomAsesAlu();
        }

        

        
    }
}
