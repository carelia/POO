﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POO8
{
    class Alumno : Persona
    {
        protected string _noCon;
        int _calif;

        public void Leer(DataGridView dGV)
        {
            _noCon = dGV[3, 0].Value.ToString();
            _calif = Convert.ToInt32(dGV[4, 0].Value);
            base.Leer(dGV);
        }
        public void Visua(DataGridView dGV)
        {
            dGV[3, 0].Value = _noCon;
            dGV[4, 0].Value = _calif.ToString();
            base.Visua(dGV);
        }
        public double MitadEdad
        {
            get { return _edad / 2.0; }
        }
    }
}
