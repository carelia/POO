﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POO8
{
    class Profesor : Persona
    {
        string _grado;
        string _noTarj;

        public void Leer(DataGridView dGV)
        {
            _grado = dGV[3, 0].Value.ToString();
            _noTarj = dGV[4, 0].Value.ToString();
            base.Leer(dGV);
        }
        public void Visua(DataGridView dGV)
        {
            dGV[3, 0].Value = _grado;
            dGV[4, 0].Value = _noTarj;
            base.Visua(dGV);
        }
        public double MitadEdad
        {
            get { return _edad / 2.0; }
        }
    }
}
