﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POO8
{
    class Persona
    {
        protected string _nombre;
        protected int _edad;
        char _sexo;
        
        public void Leer(DataGridView dGV)
        {
            _nombre = dGV[0, 0].Value.ToString();
            _edad = Convert.ToInt32(dGV[1, 0].Value);
            _sexo = Convert.ToChar(dGV[2, 0].Value);
        }
        public void Visua(DataGridView dGV)
        {
            dGV[0, 0].Value = _nombre;
            dGV[1, 0].Value = _edad.ToString();
            dGV[2, 0].Value = _sexo.ToString();
        }
    }
}
