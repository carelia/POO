﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POO8
{
    class Empleado : Persona
    {
        string _puesto;
        int _salario;

        public void Leer(DataGridView dGV)
        {
            _puesto = dGV[3, 0].Value.ToString();
            _salario = Convert.ToInt32(dGV[4, 0].Value);
            base.Leer(dGV);
        }
        public void Visual(DataGridView dGV)
        {
            dGV[3, 0].Value = _puesto;
            dGV[4, 0].Value = _salario.ToString();
            base.Visua(dGV);
        }
        public double MitadEdad
        {
            get { return _edad / 2.0; }
        }
    }
}
