﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    class Triangulo : Figura
    {
        public Triangulo(float valor1, float valor2, float valor3, float area, float perimetro, float basefig) : base(valor1, valor2, valor3, area, perimetro, basefig)
        {

        }
        public override string calcularResultado()
        {
            if (valor1obj == valor2obj && valor2obj == valor3obj)
            {
                areaobj = (valor1obj * baseobj) / 2;
                perimetroobj = valor1obj + valor2obj + valor3obj;
                return "El triangulo es tipo Equilatero" + "\n" + "El area del triangulo es:" + areaobj + "\n" + "El perimetro del triangulo es:" + perimetroobj + "\n" + "";
            }
            else if (valor1obj != valor2obj && valor2obj != valor3obj && valor3obj != valor1obj) 
            {
                areaobj = (valor1obj * baseobj) / 2;
                perimetroobj = valor1obj + valor2obj + valor3obj;
                return "El triangulo  es tipo Escaleno" + "\n" + "El area del triangulo es:" + areaobj + "\n" + "El perimetro del triangulo es:" + perimetroobj + "\n" + "";
            }
            else
            {
                areaobj = (valor1obj * baseobj) / 2;
                perimetroobj = valor1obj + valor2obj + valor3obj;
                return "El triangulo es tipo Isoceles" + "\n" + "El area del triangulo es:" + areaobj + "\n" + "El perimetro del triangulo es:" + perimetroobj + "\n" + "";
            }

            throw new NotImplementedException();
        }
    }
}
