﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    class Cuadrado : Figura
    {
        public Cuadrado(float valor1, float valor2, float valor3, float area, float perimetro, float basefig) : base(valor1, valor2, valor3, area, perimetro, basefig)
        {

        }
        public override string calcularResultado()
        {
            areaobj = valor1obj * valor1obj;
            perimetroobj = 4 * valor1obj;
            return "El area del cuadrado es:" + areaobj + "\n" + "El perimetro del cuadrado es:" + perimetroobj + "\n" + "";
            throw new NotImplementedException();
        }
    }
}
