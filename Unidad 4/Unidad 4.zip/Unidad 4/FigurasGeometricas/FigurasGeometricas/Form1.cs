﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FigurasGeometricas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Cuadrado objcuadrado = new Cuadrado(float.Parse(txtLadoCuadrado.Text), 0, 0, 0, 0, 0);
            Circulo objcirculo = new Circulo(float.Parse(txtRadio.Text), 0, 0, 0, 0, 0);
            Triangulo objtriangulo = new Triangulo(float.Parse(txtBase.Text), float.Parse(txtLadoTriangulo.Text), float.Parse(txtLado2Triangulo.Text), 0, 0, float.Parse(txtBase.Text));

            MessageBox.Show(objcuadrado.imprimirResultado()+"\n"+objcirculo.imprimirResultado()+"\n"+objtriangulo.imprimirResultado());
        }
    }
}
