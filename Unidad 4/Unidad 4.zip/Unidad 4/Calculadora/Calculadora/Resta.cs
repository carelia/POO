﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Resta:Operación
    {
        public void restar()
        {
            resultado = valor1 - valor2;
        }
    }
}
