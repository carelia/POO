﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Operación
    {
      protected   float valor1; 
       protected float valor2;
         protected float resultado;
    public float Valor1
        {
            set
            {
                valor1 = value;
            }
            get
            {
                return valor1;
            }
        }

        public float Valor2
        {
            set
            {
                valor2 = value;
            }
            get
            {
                return valor2;
            }
        }

        public float Resultado
        {
            protected set
            {
                resultado = value;
            }
            get
            {
                return resultado;
            }
        }

        public string imprimiresultado() {
            Suma objsuma = new Suma();
            Resta objresta = new Resta();
            Division objdivision = new Division();
            Multiplicacion objmultiplicacion = new Multiplicacion();
            objsuma.Valor1 = valor1;
            objsuma.Valor2=valor2;
            objsuma.sumar();
            objresta.Valor1 = valor1;
            objresta.Valor2 = valor2;
            objresta.restar();
            objmultiplicacion.Valor1 = valor1;
            objmultiplicacion.Valor2 = valor2;
            objmultiplicacion.multiplicar();
            objdivision.Valor1 = valor1;
            objdivision.Valor2 = valor2;
            objdivision.dividir();
            return "la suma de:" + valor1 + "+" + valor2 + "=" + objsuma.Resultado + " \n" +
                "la resta de:" + valor1 + "-" + valor2 + "=" + objresta.Resultado + " \n" +
                "la multiplicacion de:" + valor1 + "x" + valor2 + "=" + objmultiplicacion.Resultado + " \n" +
                " la division de: " + valor1 + "/" + valor2 + "=" + objdivision.Resultado + " \n";      
                }
    }
   
}
