﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdivinaElNumero
{
    public partial class frmInicio : Form
    {
        //Se crea un objeto de la claseLanzarNumero
        claseLanzarNumero objLanzarNumero = new claseLanzarNumero();

        //Se crea una variable de tipo entero
        int numeroaAdivinar;
        //Se crea la variable de numeros de intentos
        int intentosrestantes = 3;

        public frmInicio()
        {
            InitializeComponent();
            txtNumeroIngresado.Visible = false;
            btnVerificar.Visible = false;
            lblIntentos.Text = intentosrestantes.ToString();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            //Se ejecuta el metodo de la claseLanzarNumero y se guarda en la variable de tipo entero
            numeroaAdivinar =  objLanzarNumero.numeroValido();

            //EL boton de iniciar juego se hace invisible
            btnIniciar.Visible = false;

            //Se muestran los siguiente mensajes en las etiquetas
            lblMensajes.Text = "El número a adivinar está listo, recuerda que el número debe de estar entre numero del 0 al 10";

            txtNumeroIngresado.Visible = true;
            btnVerificar.Visible = true;

            lblNumero.Text = "---";
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if(int.Parse(txtNumeroIngresado.Text) == numeroaAdivinar)
            {
                lblMensajes.Text = "Felicidades ganaste";
                btnIniciar.Visible = true;
                txtNumeroIngresado.Text = "";
                txtNumeroIngresado.Visible = false;
                btnVerificar.Visible = false;
            }
            else
            {
                if(intentosrestantes==1)
                {
                    lblMensajes.Text = "Lo siento, te has quedado sin intentos, HAS PERDIDO, número era el";
                    btnIniciar.Visible = true;
                    txtNumeroIngresado.Text = "";
                    txtNumeroIngresado.Visible = false;
                    btnVerificar.Visible = false;
                    intentosrestantes = 3;
                    lblNumero.Text = numeroaAdivinar.ToString();
                }
                else
                {
                    intentosrestantes--;
                    lblIntentos.Text = intentosrestantes.ToString();
                    lblMensajes.Text = "Lo siento, aun te quedan "+intentosrestantes+" intentos más para adivinar";
                }      

            }
        }

        private void lblIntentos_Click(object sender, EventArgs e)
        {

        }
    }
}
