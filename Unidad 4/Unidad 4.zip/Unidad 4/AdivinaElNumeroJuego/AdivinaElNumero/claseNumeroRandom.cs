﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdivinaElNumero
{
    //Clase padre llamada claseNumeroRandom
    public class claseNumeroRandom
    {
        //Se crea una variable publica de tipo entero llamada numero
        public int numero;

        //Se crea un metodo de tipo entero perteneciente a la clase padre llamado nuevoNumero
        public int nuevoNumero()
        {
            //Retorna un numero entero random de valor positivo, que se encuentre entre el numero -10 y el numero 20
            return numero = new Random().Next(-10, 20);
        } 
    }
}
