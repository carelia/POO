﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdivinaElNumero
{
    //Se crea una clase hija de la claseNumeroRandom llamada claseLanzarNumero
    public class claseLanzarNumero : claseNumeroRandom
    {
        //Por automatico posee el metodo de su clase padre llamado nuevo numero

        //Se crea una variable de tipo entero llado validar
        int validar;

        //Se crea un metodo propio de la claseLanzarNumero, para validar que el numero random que se genera sea un numero entre el 0 y el 10
        //Y no entre el -10 y el 20 como lo hace en el metodo de la clase padre
        public int numeroValido()
        {
            //Hacer
            do
            {
                //Validar es igual a la ejecución del metodo random
                validar = nuevoNumero();
            }//Mientras validar sea menor a cero o mayor a 10
            while (validar < 0 || validar > 10);

            //Retornar el valor de validar
            return validar;
        }
    }
}
