﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Aereo

    {
       public  int numturbinas,numalas, numhelices;
        public string tipoaereo;
        

        public Aereo()
        {
            numalas = 0;
            numturbinas = 0;
            numhelices = 0;
            tipoaereo = "";

        }

public string envuelo(string estado)
        {
            return "El " tipoaereo , "esta volando" + estado;
        }
    }
}
