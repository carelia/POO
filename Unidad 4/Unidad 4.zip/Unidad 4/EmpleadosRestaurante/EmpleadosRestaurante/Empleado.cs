﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpleadosRestaurante
{
        abstract class Empleado
        {
            protected string nombreEmpleado;
            protected DateTime fechanacimiento;
            protected int diastrabajados;
            protected float sueldo;

            public Empleado(string nombreEmpleadoobt, DateTime fechanacimientoobt, int diastrabajadosobt, float sueldoobt)
            {
                nombreEmpleado = nombreEmpleadoobt;
                fechanacimiento = fechanacimientoobt;
                diastrabajados = diastrabajadosobt;
                sueldo = sueldoobt;
            }
            public abstract string calcularsueldo();
        }
}
