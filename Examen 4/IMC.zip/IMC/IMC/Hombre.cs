﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace IMC
{
    class Hombre : Persona
    {
        public String Nombre;

        public int Edad;

        public String RFC;

        public float Peso, Altura;
       
        double IMC;
        String mensaje;


        public string CalcularIMCHombre( float Peso, float Altura)
        { 

           Hombre Hombre = new Hombre();
            Hombre.Peso = Peso;
            Hombre.Altura = Altura;
            double IMC = (Hombre.Peso / (Hombre.Altura * Hombre.Altura) + 2);
            if (IMC < 20)
            {
                mensaje = "Peso Ideal";
            }
            else if (IMC >= 20 || IMC <= 25)
            {
                mensaje = "Peso Bajo";
            }
            else if (IMC > 25)
            {
                mensaje = "Sobrepeso";
            }
            return mensaje;
        }

    }
}

    





