﻿using System;

namespace IMC
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
