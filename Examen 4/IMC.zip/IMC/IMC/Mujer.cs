﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMC
{
    class Mujer : Persona
    {
        public String Nombre;

        public int Edad;

        public String RFC;

        public float Peso, Altura;
        double IMC;
        String mensaje;
        public string CalcularIMCMujer(float Peso, float Altura)
        {
            Mujer Mujer = new Mujer();
            Mujer.Peso = Peso;
            Mujer.Altura = Altura;
            double IMC = (Mujer.Peso / (Mujer.Altura * Mujer.Altura) - 1);
            if (IMC < 20)
            {
                mensaje = "Peso Ideal";
            }
            else if (IMC >= 20 || IMC <= 25)
            {
                mensaje = "Peso Bajo";
            }
            else if (IMC > 25)
            {
                mensaje = "Sobrepeso";
            }
            return mensaje;
        }
    }
}
