﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMC
{
    class Persona
    {
       String Nombre;

         int Edad;

        String Sexo;

        float Peso, Altura;
       
    }
    
   

        }

    }

    





}
}
