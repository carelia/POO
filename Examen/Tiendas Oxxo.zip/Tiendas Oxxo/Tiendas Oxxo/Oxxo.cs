﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Tiendas_Oxxo
{
    class Oxxo
    {
        int SumaVentasTienda;
       
        int PromVentasEnero;
        int MesMenorVentas;
        int VentasMasAlta;
      

        string[,] MatrizVentas;
        int[] VentasMes;
        string[] VentasTienda;
        public void ImprimirMatriz()
        {
        }
        public void CalcularSumaVentasTienda()
        {
            for (int i = 0; i < MatrizVentas.GetLength(0); i++)
            {
                int suma = 0;

                for (int j = 0; j < MatrizVentas.GetLength(1); j++)
                {
                    suma += Convert.ToInt32(MatrizVentas[i, j]);

                }
                VentasTienda[i] = suma;


            }

        }
        public void CalcularSumaVentasMes()
        {
            for (int i = 0; i < MatrizVentas.GetLength(0); i++)
            {
              int suma = 0;
               
                for (int j = 0; j < MatrizVentas.GetLength(1); j++)
                {
                    suma += Convert.ToInt32(MatrizVentas[i, j]);
                  
                }
                VentasMes[i] = suma;


            }
        }

        public void CalculaPromedioEnero()
        {

        }
        public void ObtenerMesConMenorVenta()

        {
            int Mayor = -99;
            for (int j = 0; j < VentasTienda.GetLength(0); j++)
            {
                if (Mayor < VentasTienda[j])
                {
                    if (j == 1)
                    {
                        MesMenorVentas = +"se realizaron las ventas:+VentasTienda[j]+"en el mes de enero";     
                    }
                }
            }
        }
        
        public void ObtenerVentaMasAlta()
        { }

    }
}