﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiendas_Oxxo
{
    public partial class Form1 : Form
    {
        Oxxo objOxxo = new Oxxo();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregarDatos_Click(object sender, EventArgs e)
        {
            if (cmbTienda.Text == "Ixtlan 1")
            {

            }
            else if (cmbTienda.Text == "Ixtlan 2")
            {
            }
            else if (cmbTienda.Text == "Ixtlan 3")
            {

            }
            else if (cmbTienda.Text == "Ahuacatlan 4")
                { }

            else if (cmbTienda.Text == "Jala 5")
            { }
        }
    }
}
