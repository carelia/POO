﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Ejercicio1
{
    public partial class Form1 : Form

    {

        private List<Pais> Paises = new List<Pais>(); //yo cree la variable privada para guardar todo lo que se valla a crear en ella

        public Form1()
        {
            InitializeComponent();

        }

        private void BtnGuardar_Click(object sender, EventArgs e)

        {
            if (CamposVacios()) { MessageBox.Show("No puede dejar campos vacios"); return; }// para validar campos vacios
            Pais pais = new Pais(); //Creacion de un objeto en este caso pais

            pais.Nombre = tbNombre.Text; //Atributos
            pais.Poblacion = tbPoblacion.Text;
            pais.Idioma = tbIdioma.Text;
            pais.Colores[0] = tbColor1.Text;
            pais.Colores[1] = tbColor2.Text;
            pais.Colores[2] = tbColor3.Text;

            Paises.Add(pais); // Guardar en un ArrayList


            tbNombre.Text = ""; // esto es para limpiar el formulario despues de haber guardado los datos
            tbPoblacion.Text = "";
            tbIdioma.Text = "";
            tbColor1.Text = "";
            tbColor2.Text = "";
            tbColor3.Text = "";
            MessageBox.Show("Datos guardados correctamente");

        }

        public bool CamposVacios()//clase creada para los campos vacios esto es para que ningun campo se deje en blanco
        {
            if (tbNombre.Text == "") return true;
            else if (tbPoblacion.Text == "") return true;
            else if (tbIdioma.Text == "") return true;
            else if (tbColor1.Text == "" || tbColor2.Text == "" || tbColor3.Text == "") return true;
            else return false;
        }

        private void BtnImprimir_Click(object sender, EventArgs e)
        {


            if (!(Paises.Count > 0)) { MessageBox.Show("No se tiene registrado ningun dato todavia"); return; }//valida el  ArrayList

            dgvDatos.Rows.Clear();//limpiar los datos registrados en la datagrid view

            DataGridViewRow fila = new DataGridViewRow(); //Guardar los datos en el arrayList 
            fila.CreateCells(dgvDatos);
            Pais pais = new Pais();

            for (int i = 0; i < Paises.Count; i++)
            {
                
                {
                    pais = Paises[i];
               


                }
                pais = Paises[i];
                fila.Cells[0].Value = pais.Nombre;
                fila.Cells[1].Value = pais.Poblacion;
                fila.Cells[2].Value = pais.Idioma;
                fila.Cells[3].Value = pais.Colores[0] + ", " + pais.Colores[1] + ", " + pais.Colores[2]; //Guardar  los 3 colores para ponerlos en una sola celda
                dgvDatos.Rows.Add(fila);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

   

