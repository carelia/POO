﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4
{
    public partial class DatosAlumno : Form
    {
        public DatosAlumno(List<Alumno> alumnos)
        {
            InitializeComponent();
            DataGridViewRow fila;
            Alumno alumno;
            for (int i = 0; i < alumnos.Count; i++)
            {
                alumno = alumnos[i];
                fila = new DataGridViewRow();
                fila.CreateCells(dgvDatos);
                fila.Cells[0].Value = alumno.Nombre;
                fila.Cells[1].Value = alumno.FechaNacimiento;
                fila.Cells[2].Value = alumno.Curp;
                fila.Cells[3].Value = alumno.Telefono;
                fila.Cells[4].Value = alumno.Email;
                fila.Cells[5].Value = alumno.NoControl;
                dgvDatos.Rows.Add(fila);
            }
        }

        private void DatosAlumno_Load(object sender, EventArgs e)
        {

        }
    }
}
