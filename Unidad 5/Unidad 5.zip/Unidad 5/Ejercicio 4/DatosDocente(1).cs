﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4
{
    public partial class DatosDocente : Form
    {
        public DatosDocente(List<Docente> docentes)
        {
            InitializeComponent();
            Docente docente = new Docente();
            DataGridViewRow fila;
            for (int i = 0; i < docentes.Count; i++)
            {
                docente = docentes[i];
                fila = new DataGridViewRow();
                fila.CreateCells(dgvDatos);
                fila.Cells[0].Value = docente.Nombre;
                fila.Cells[1].Value = docente.FechaNacimiento;
                fila.Cells[2].Value = docente.Curp;
                fila.Cells[3].Value = docente.Telefono;
                fila.Cells[4].Value = docente.Email;
                fila.Cells[5].Value = docente.NoMaestro;
                fila.Cells[6].Value = docente.Sueldo;
                dgvDatos.Rows.Add(fila);
            }
            
           
           
        }

        private void DatosDocente_Load(object sender, EventArgs e)
        {

        }
    }
}
