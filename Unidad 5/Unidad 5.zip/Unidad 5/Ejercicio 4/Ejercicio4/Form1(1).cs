﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4
{
    public partial class Form1 : Form
    {
        List<Alumno> alumnos = new List<Alumno>();

        List<Docente> docentes = new List<Docente>();
        public Form1()
        {
            InitializeComponent();
           
            
        }

        private void BtnAlumno_Click(object sender, EventArgs e)
        {
            FormAlumno fmalumno = new FormAlumno();
            DialogResult res = fmalumno.ShowDialog();
            if (res == DialogResult.OK)
            {//PAra pasar el objeto creado en el formulario mostrado
                alumnos.Add(fmalumno.alumno);
            }
        }

        private void BtnImpralu_Click(object sender, EventArgs e)
        {
            if (alumnos.Count == 0) { MessageBox.Show("Aun no se han capturado los datos del alumno"); return; }
            DatosAlumno datos = new DatosAlumno(alumnos);
            datos.Show();
        }
        private void Button1_Click_1(object sender, EventArgs e)
        {
            if (docentes.Count == 0) { MessageBox.Show("Aun no se han capturado los datos del Docente"); return; }
            DatosDocente datos = new DatosDocente(docentes);
            datos.Show();
        }

        private void BtnDocente_Click_1(object sender, EventArgs e)
        {
            FormDocente fmdocente = new FormDocente();
            DialogResult res = fmdocente.ShowDialog();
            if (res == DialogResult.OK)
            {
                docentes.Add(fmdocente.docente);
            }
        }
    }
}
