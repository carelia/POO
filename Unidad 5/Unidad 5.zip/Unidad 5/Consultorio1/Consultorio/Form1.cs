﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Consultorio
{
    public partial class Form1 : Form
  
    {
        Estadistica objEstadistica = new Estadistica();
        int NoDeRegistros = 0;
       
        
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbTotal.Text = "0";
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (!Validar()) return;

            objEstadistica.EdadEnfermedad[0, NoDeRegistros] = cbEnfermedad.Text;
           
            objEstadistica.EdadEnfermedad[1, NoDeRegistros] = tbEdad.Text;
            NoDeRegistros++;
            lbTotal.Text = NoDeRegistros.ToString();
            tbEdad.Text = "";
            cbEnfermedad.Text = "";

        }
        public bool Validar()
        {
            if(tbEdad.Text == "" || cbEnfermedad.Text == "")
            {
                MessageBox.Show("No puede dejar campos vacios");
                return false;
            }

            try
            {
                Convert.ToInt32(tbEdad.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("El campo edad solo acepta numeros");
            }
            return true;
        }

        private void BtnImprimir_Click(object sender, EventArgs e)
        {
            if (lbTotal.Text == "0")
                
            {
                MessageBox.Show("Aun no tiene registros");
                
                return;
            }
            objEstadistica.Calcular(NoDeRegistros);
            lbCantRenal.Text = objEstadistica.TotalPorEnfermedad[0].ToString();
            lbCantCardiaca.Text = objEstadistica.TotalPorEnfermedad[1].ToString();
            lbCantRespiratoria.Text = objEstadistica.TotalPorEnfermedad[2].ToString();
            lbCantDigestiva.Text = objEstadistica.TotalPorEnfermedad[3].ToString();

            lbPromRenal.Text = objEstadistica.PromedioPorEnfermedad[0].ToString();
            
            lbPromCardiaca.Text = objEstadistica.PromedioPorEnfermedad[1].ToString();
           
           
         lbPromRespiratoria.Text = objEstadistica.PromedioPorEnfermedad[2].ToString();
            lbPromDigestiva.Text = objEstadistica.PromedioPorEnfermedad[3].ToString();

            lbEnfermedadComun.Text = objEstadistica.EnfermedadComun;

           

          
        }
       
        private void CbEnfermedad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
