﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NumerosMayorMenor
{
    class numeros
    {
        int[] array = new int[2];
        int menor = 0, mayor = 0;
       
    }
}
