﻿using System;
using System.IO;
namespace Ejemplo1Propuesto
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            
            char[] vector ={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t',
                'u','v','w','x','y','z',};
            Console.Write("\n ingresa el numero del:[1_26]");
           
            numero =int.Parse(Console.ReadLine());
            Console.Write("El numero que elegiste corresponde a la posicion de la letra: ");
            if (numero > 0 && numero <= 26)
                Console.Write(vector[numero - 1]);
           
            else
               
            Console.Write("Ingrese un valor[1-26]");
          
            
            Console.ReadKey();

        }
    }
}
