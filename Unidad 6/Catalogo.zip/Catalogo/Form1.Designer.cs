﻿namespace Catalogo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.cbPrograma = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rtbInfo = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(648, 9);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(61, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Ejecutar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // cbPrograma
            // 
            this.cbPrograma.BackColor = System.Drawing.SystemColors.Info;
            this.cbPrograma.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPrograma.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbPrograma.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPrograma.FormattingEnabled = true;
            this.cbPrograma.Items.AddRange(new object[] {
            "Mi Primer Solucion",
            "Area Y Perimetro",
            "Calculadora de Promedios",
            "Autopista",
            "Electricidad",
            "Vacaciones",
            "Embotelladora",
            "Fecha de Nacimiento",
            "Convertidor de Grados",
            "Calculadora",
            "Vehiculos",
            "Empleados Restaurante",
            "Figuras Geometricas",
            " Adivina El Numero Juego",
            "Ejemplo 1 Propuesto",
            "Mi Primera Clase",
            "Ejercicio 1 Paises",
            "Ejercicio 2 Cantidad de Paises",
            "Ejercicio 3  Docentes",
            "Ejercicio 4 Alumnos",
            "Bidimensional 1",
            "Bidimensional 2",
            "Bidimensional 3",
            "Numero Mayor Y Menor",
            "Matrices ",
            "Consultorio",
            "Ejemplo 1 Propuesto Archivos",
            "Mi Primera Clase Archivos",
            "Ejercicio 1 Paises Archivos",
            "Ejercicio 2 Cantidad de Paises Archivos",
            "Ejercicio 3  Docentes Archivos",
            "Ejercicio 4 Alumnos Archivos",
            "Bidimensional 1 Archivos",
            "Bidimensional 2 Archivos",
            "Bidimensional 3 Archivos",
            "Numero Mayor Y Menor Archivos",
            "Matrices Archivos",
            "Consultorio Archivos"});
            this.cbPrograma.Location = new System.Drawing.Point(393, 11);
            this.cbPrograma.Margin = new System.Windows.Forms.Padding(2);
            this.cbPrograma.MaxDropDownItems = 10;
            this.cbPrograma.Name = "cbPrograma";
            this.cbPrograma.Size = new System.Drawing.Size(238, 30);
            this.cbPrograma.TabIndex = 1;
            this.cbPrograma.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(301, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Elija un programa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 120);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Información";
            // 
            // rtbInfo
            // 
            this.rtbInfo.Location = new System.Drawing.Point(129, 135);
            this.rtbInfo.Margin = new System.Windows.Forms.Padding(2);
            this.rtbInfo.Name = "rtbInfo";
            this.rtbInfo.Size = new System.Drawing.Size(485, 306);
            this.rtbInfo.TabIndex = 5;
            this.rtbInfo.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(736, 483);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 483);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rtbInfo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbPrograma);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbPrograma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox rtbInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

