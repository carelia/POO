﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Catalogo
{
    public partial class Form1 : Form
    {

        string RutaProgramas = Path.GetDirectoryName(Path.GetDirectoryName(Directory.GetCurrentDirectory())) + @"\programas\";
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
           int opc = cbPrograma.SelectedIndex;
            string ruta = "";
            try
            {
                switch (opc)
                {
                    case 0:
                        ruta = RutaProgramas + @"MiPrimerSolucion\MiPrimerProyectoWindowsForms\bin\debug\MiPrimerProyectoWindowsForms.exe";
                        Process.Start(ruta);
                        break;

                   case 1:
                        ruta = RutaProgramas + @"AreaYPerimetro\AreaYPerimetro\bin\Debug\AreaYPerimetro.exe";
                        Process.Start(ruta);

                        break;
                    case 2:
                        ruta = RutaProgramas + @"CalculadoraDePromedios\CalculadoraDePromedios\bin\Debug\CalculadoraDePromedios.exe";
                        Process.Start(ruta);
                        break;
                    case 3:
                        ruta = RutaProgramas + @"Autopista\Autopista\bin\Debug\Autopista.exe";
                        Process.Start(ruta);
                        break;
                    case 4:
                        ruta = RutaProgramas + @"Electricidad\Electricidad\bin\Debug\Electricidad.exe";
                        Process.Start(ruta);

                        break;
                    

                    
                    case 5:
                        ruta = RutaProgramas + @"Vacaciones\Vacaciones\bin\Debug\Vacaciones.exe";
                        Process.Start(ruta);

                        break;
                    case 6:
                        ruta = RutaProgramas + @"Embotelladora\bin\Debug\Embotelladora.exe";
                        Process.Start(ruta);

                        break;
                    case 7:
                        ruta = RutaProgramas + @"FechaNacimiento\FechaNacimiento\bin\Debug\FechaNacimiento.exe";
                        Process.Start(ruta);

                        break;
                    case 8:
                        ruta = RutaProgramas + @"ConvertidorDeGrados\ConvertidorDeGrados\bin\Debug\ConvertidorDeGrados.exe";
                        Process.Start(ruta);

                        break;
                    
                    case 9:
                        ruta = RutaProgramas + @"Calculadora\Calculadora\bin\debug\Calculadora.exe";
                        Process.Start(ruta);
                        break;
                    case 10:
                        ruta = RutaProgramas + @"Vehiculos\bin\Debug\Vehiculos.exe";
                        Process.Start(ruta);
                        break;
                    case 11:
                        ruta = RutaProgramas + @"EmpleadosRestaurante\EmpleadosRestaurante\bin\Debug\EmpleadosRestaurante.exe";
                        Process.Start(ruta);
                        break;

                    case 12:
                        ruta = RutaProgramas + @"FigurasGeometricas\FigurasGeometricas\bin\Debug\FigurasGeometricas.exe";
                        Process.Start(ruta);
                        break;
                    case 13:
                        ruta = RutaProgramas + @"AdivinaElNumeroJuego\AdivinaElNumero\bin\Debug\AdivinaElNumero.exe";
                        Process.Start(ruta);
                        break;
                    case 14:
                        ruta = RutaProgramas + @"Unidad 5\Ejemplo1Propuesto\bin\Debug\netcoreapp3.1\Ejemplo1Propuesto.exe";
                        Process.Start(ruta);
                        break;
                    case 15:
                        ruta = RutaProgramas + @"MiPrimeraClase\MiPrimeraClase\bin\Debug\Array.exe";
                        Process.Start(ruta);
                        break;
                    case 16:
                        ruta = RutaProgramas + @"Ejercicio 1\bin\Debug\Ejercicio1.exe";
                        Process.Start(ruta);
                        break;
                    case 17:
                        ruta = RutaProgramas + @"Ejercicio 2\bin\Debug\CantidadPaises.exe";
                        Process.Start(ruta);
                        break;
                    case 18:
                        ruta = RutaProgramas + @"Ejercicio 3\bin\Debug\Ejercicio3.exe";
                        Process.Start(ruta);
                        break;
                    case 19:
                        ruta = RutaProgramas + @"Ejercicio 4\bin\Debug\Ejercicio4.exe";
                        Process.Start(ruta);
                        break;
                    case 20:
                        ruta = RutaProgramas + @"Bidimensional 1\bin\Debug\Bidimensional.exe";
                        Process.Start(ruta);
                        break;
                    case 21:
                        ruta = RutaProgramas + @"Bidimensional 2\bin\Debug\Bidimensional2.exe";
                        Process.Start(ruta);

                        break;
                    case 22:
                        ruta = RutaProgramas + @"Bidimensional 3\bin\Debug\BidimensionalEjemplo.exe";
                        Process.Start(ruta);
                        break;
                    case 23:
                        ruta = RutaProgramas + @"NumerosMayorMenor\bin\Debug\netcoreapp3.1\NumerosMayorMenor";
                        Process.Start(ruta);
                        break;
                    case 24:
                        ruta = RutaProgramas + @"FilasColumnasDiagonal\bin\Debug\FilasColumnasDiagonal.exe";
                        Process.Start(ruta);
                        break;
                    case 25:
                        ruta = RutaProgramas + @"Consultorio1\bin\Debug\Consultorio.exe";
                        Process.Start(ruta);
                        break;
                    case 26:
                        ruta = RutaProgramas + @"Unidad 6 Archivos\Ejemplo1Propuesto\bin\Debug\netcoreapp3.1\Ejemplo1Propuesto.exe";
                        Process.Start(ruta);
                        break;
                    case 27:
                        ruta = RutaProgramas + @"MiPrimeraClase Archivos\MiPrimeraClase\bin\Debug\Array.exe";
                        Process.Start(ruta);
                        break;
                    case 28:
                        ruta = RutaProgramas + @"Ejercicio 1 Archivos\bin\Debug\Ejercicio1.exe";
                        Process.Start(ruta);
                        break;
                    case 29:
                        ruta = RutaProgramas + @"Ejercicio 2 Archivos\bin\Debug\CantidadPaises.exe";
                        Process.Start(ruta);
                        break;
                    case 30:
                        ruta = RutaProgramas + @"Ejercicio 3 Archivos\bin\Debug\Ejercicio3.exe";
                        Process.Start(ruta);
                        break;
                    case 31:
                        ruta = RutaProgramas + @"Ejercicio 4 Archivos\bin\Debug\Ejercicio4.exe";
                        Process.Start(ruta);
                        break;
                    case 32:
                        ruta = RutaProgramas + @"Bidimensional 1 Archivos\bin\Debug\Bidimensional.exe";
                        Process.Start(ruta);
                        break;
                    case 33:
                        ruta = RutaProgramas + @"Bidimensional 2 Archivos\bin\Debug\Bidimensional2.exe";
                        Process.Start(ruta);

                        break;
                    case 34:
                        ruta = RutaProgramas + @"Bidimensional 3 Archivos\bin\Debug\BidimensionalEjemplo.exe";
                        Process.Start(ruta);
                        break;
                    case 35:
                        ruta = RutaProgramas + @"NumerosMayorMenor Archivos\NumerosMayorMenor\bin\Debug\netcoreapp3.1\NumerosMayorMenor";
                        Process.Start(ruta);
                        break;
                    case 36:
                        ruta = RutaProgramas + @"FilasColumnasDiagonal Archivos\FilasColumnasDiagonal\bin\Debug\FilasColumnasDiagonal.exe";
                        Process.Start(ruta);
                        break;
                    case 37:
                        ruta = RutaProgramas + @"Consultorio1 Archivos\Consultorio1\bin\Debug\Consultorio.exe";
                        Process.Start(ruta);
                        break;




                    default: MessageBox.Show("Primero elija un programa"); break;

                }
            }
            catch(Exception)
            {
                MessageBox.Show("No se encontró el archivo: " + ruta);
            }
         
    
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int opc = cbPrograma.SelectedIndex;
            switch (opc)
            {
                case 0:
                    rtbInfo.Text = "Informacion del programa 1";
                    
                    break;
                case 1:
                    rtbInfo.Text = "Informacion del programa 2";
                    break;
                case 2:
                    rtbInfo.Text = "Informacion del programa 3";
                    break;
                case 3:
                    rtbInfo.Text = "Informacion del programa 4";
                    break;
                case 4:
                    rtbInfo.Text = "Informacion del programa 5";
                    break;
                case 5:
                    rtbInfo.Text = "Informacion del programa 6";
                    break;
                case 6:
                    rtbInfo.Text = "Informacion del programa 7";
                    break;
                case 7:
                    rtbInfo.Text = "Informacion del programa 8";
                    break;
                case 8:
                    rtbInfo.Text = "Informacion del programa 9";
                    break;
                case 9:
                    rtbInfo.Text = "Informacion del programa 10";
                    break;
                case 10:
                    rtbInfo.Text = "Informacion del programa 11";
                    break;
                case 11:
                    rtbInfo.Text = "Informacion del programa 12";
                    break;
                case 12:
                    rtbInfo.Text = "Informacion del programa 13";
                    break;
                case 13:
                    rtbInfo.Text = "Informacion del programa 14";
                    break;
                case 14:
                    rtbInfo.Text = "Informacion del programa 15";
                    break;
                case 15:
                    rtbInfo.Text = "Informacion del programa 16";
                    break;
                case 16:
                    rtbInfo.Text = "Informacion del programa 17";
                    break;
                case 17:
                    rtbInfo.Text = "Informacion del programa 18";
                    break;
                case 18:
                    rtbInfo.Text = "Informacion del programa 19";
                    break;
                case 19:
                    rtbInfo.Text = "Informacion del programa 20";
                    break;
                case 20:
                    rtbInfo.Text = "Informacion del programa 21";
                    break;
                case 21:
                    rtbInfo.Text = "Informacion del programa 22";
                    break;
                case 22:
                    rtbInfo.Text = "Informacion del programa 23";
                    break;
                case 23:
                    rtbInfo.Text = "Informacion del programa 24";
                    break;
                case 24:
                    rtbInfo.Text = "Informacion del programa 25";
                    break;
                case 25:
                    rtbInfo.Text = "Informacion del programa 26";
                    break;
                case 26:
                    rtbInfo.Text = "Informacion del programa 27";
                    break;
                case 27:
                    rtbInfo.Text = "Informacion del programa 28";
                    break;
                case 28:
                    rtbInfo.Text = "Informacion del programa 29";
                    break;
                case 29:
                    rtbInfo.Text = "Informacion del programa 30";
                    break;
                case 30:
                    rtbInfo.Text = "Informacion del programa 31";
                    break;
                case 31:
                    rtbInfo.Text = "Informacion del programa 32";
                    break;
                case 32:
                    rtbInfo.Text = "Informacion del programa 33";
                    break;
                case 33:
                    rtbInfo.Text = "Informacion del programa 34";
                    break;
                case 34:
                    rtbInfo.Text = "Informacion del programa 35";
                    break;
                case 35:
                    rtbInfo.Text = "Informacion del programa 36";
                    break;
                case 36:
                    rtbInfo.Text = "Informacion del programa 37";
                    break;
                case 37:
                    rtbInfo.Text = "Informacion del programa 38";
                    break;
                



                default: rtbInfo.Text = ""; break;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
