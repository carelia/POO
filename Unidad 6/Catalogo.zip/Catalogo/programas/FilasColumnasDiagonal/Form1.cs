﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FilasColumnasDiagonal
{
    public partial class Form1 : Form
    {
        Arreglo objArreglo = new Arreglo();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (nudCantidad.Value < 2)
            {
                MessageBox.Show("Debe de ingresar un igual o mayor a 2");
                return;
            }
            objArreglo.Num = (int)nudCantidad.Value;
            objArreglo.Matriz = new int[(int)nudCantidad.Value, (int)nudCantidad.Value];
            try
            {
                for (int f = 0; f < objArreglo.Num; f++)
                {
                    for (int c = 0; c < objArreglo.Num; c++)
                    {
                        objArreglo.Matriz[f, c] = Convert.ToInt32(Interaction.InputBox("Introduce el valor para Fila" + (f + 1) + " Columna " + (c + 1)));
                        
                    }
                }  
            }
            catch (Exception)
            {
                MessageBox.Show("Se ha ingresado un dato no numerico o se canceló la operación.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            TextWriter archivo;
            archivo = new StreamWriter("archivo.txt");
            if (objArreglo.Num<2)
            {
                MessageBox.Show("No se han capturado datos todavia");
                return;
            }
            if (rtbMatriz.Text != "") return;
            limpiar();
            objArreglo.SumarFilas();
            objArreglo.SumarColumnas();
            objArreglo.SumarDiagonal();
            for (int f = 0; f < objArreglo.Num; f++)
            {
                for (int c = 0; c < objArreglo.Num; c++)
                {
                    rtbMatriz.Text += objArreglo.Matriz[f, c].ToString() + "  ";
       
                    
                }
                rtbMatriz.Text += "\n";
            }
            archivo.WriteLine(rtbMatriz.Text);
            for (int i = 0; i < objArreglo.Num; i++)
            {
                lblSumaColumnas.Text += objArreglo.SumCol[i].ToString() + " ";
                lblSumaFilas.Text += "\n" + objArreglo.SumFila[i].ToString();
            }
            lblSumaDiagonal.Text += objArreglo.SumDiagonal.ToString();
            archivo.WriteLine("La suma diagonal es: "+ lblSumaDiagonal.Text);
            archivo.WriteLine("La suma columnas es: " + lblSumaColumnas.Text);
            archivo.WriteLine("La suma filas es: " + lblSumaFilas.Text);

            archivo.Close();
        }
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            limpiar();
        }
        public void limpiar()
        {
            rtbMatriz.Clear();
            lblSumaColumnas.Text = "Suma de Columnas: ";
            lblSumaDiagonal.Text = "Suma de Diagonal: ";
            lblSumaFilas.Text = "Suma de Filas:";
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
