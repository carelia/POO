﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilasColumnasDiagonal
{
    class Arreglo
    {
        public int[,] Matriz{ set; get; }//Matriz
        public int[] SumFila { set; get; }//Suma de cada fila
        public int[] SumCol { set; get; }// Suma de cada columna
        public int SumDiagonal { set; get; } //Suma de la diagonal
        public int Num{ set; get; } //Numero de filas y columnas

        public void SumarFilas()
        {
            int suma;
            SumFila = new int [Num];
            for (int f = 0; f < Num; f++) //f filas c columnas
            {
                suma = 0;
                for (int c = 0; c < Num; c++)
                {
                    suma += Matriz[f,c];
                }
                SumFila[f] = suma;
            }
        }

        public void SumarColumnas()
        {
            int suma;
            SumCol = new int[Num];
            for (int c = 0; c < Num; c++)
            {
                suma = 0;
                for (int f = 0; f < Num; f++)
                {
                    suma += Matriz[f, c];
                }
                SumCol[c] = suma;
            }
        }

        public void SumarDiagonal()
        {
            int suma = 0;
            int c = 0;
            for (int f = 0; f < Num; f++)
            {
                suma += Matriz[f, c];
                c++;
            }
            SumDiagonal = suma;
        }
    }
}
