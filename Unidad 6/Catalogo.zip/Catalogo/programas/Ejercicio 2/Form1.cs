﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CantidadPaises
{
    public partial class Form1 : Form
    {
        int cantidad;
        int contador = 1;
        int i = 0;

        Paises[] objPaises;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            cantidad = Convert.ToInt32 (txtCantidad.Text);

            this.btnGuardar.Enabled = true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "")
            {
                errorProvider1.SetError(txtNombre, "Debe introducir el nombre del país");
                txtNombre.Focus();
                return;
            }
            errorProvider1.SetError(txtNombre, "");

            if (txtPoblacion.Text == "")
            {
                errorProvider1.SetError(txtPoblacion, "Debe introducir la cantidad de población");
                txtPoblacion.Focus();
                return;
            }
            errorProvider1.SetError(txtPoblacion, "");

            if (txtColor1.Text == "")
            {
                errorProvider1.SetError(txtColor1, "Debe introducir el primer color de la bandera");
                txtColor1.Focus();
                return;
            }
            errorProvider1.SetError(txtColor2, "");

            if (txtColor1.Text == "")
            {
                errorProvider1.SetError(txtColor2, "Debe introducir el segundo color de la bandera");
                txtColor2.Focus();
                return;
            }
            errorProvider1.SetError(txtColor2, "");

            if (txtColor3.Text == "")
            {
                errorProvider1.SetError(txtColor3, "Debe introducir el tercer color de la bandera");
                txtColor1.Focus();
                return;
            }
            errorProvider1.SetError(txtColor3, "");

            if (contador == 1)
            {
                objPaises = new Paises[cantidad];
            }

            if (contador < cantidad)
            {
                objPaises[i] = new Paises();

                objPaises[i].Nombre = txtNombre.Text;
                objPaises[i].Poblacion = Convert.ToInt32 (txtPoblacion.Text);
                objPaises[i].Idioma = txtIdioma.Text;

                objPaises[i].ColBandera = new string[3];

                objPaises[i].ColBandera[0] = txtColor1.Text;
                objPaises[i].ColBandera[1] = txtColor2.Text;
                objPaises[i].ColBandera[2] = txtColor3.Text;

                txtNombre.Text = "";
                txtPoblacion.Text = "";
                txtIdioma.Text = "";
                txtColor1.Text = "";
                txtColor2.Text = "";
                txtColor3.Text = "";

                contador++;
                i++;
            }
            else if (contador == cantidad)
            {
                objPaises[i] = new Paises();

                objPaises[i].Nombre = txtNombre.Text;
                objPaises[i].Poblacion = Convert.ToInt32(txtPoblacion.Text);
                objPaises[i].Idioma = txtIdioma.Text;

                objPaises[i].ColBandera = new string[3];

                objPaises[i].ColBandera[0] = txtColor1.Text;
                objPaises[i].ColBandera[1] = txtColor2.Text;
                objPaises[i].ColBandera[2] = txtColor3.Text;

                txtNombre.Text = "";
                txtPoblacion.Text = "";
                txtIdioma.Text = "";
                txtColor1.Text = "";
                txtColor2.Text = "";
                txtColor3.Text = "";

                MessageBox.Show("Total de paises guardados");

                this.txtBuscarPais.Enabled = true;
                this.btnBuscar.Enabled = true;
            }  
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int nombre = 0;

            for (int i = 0; i < objPaises.Length; i++)
            {
                if (txtBuscarPais.Text == objPaises[i].Nombre)
                {
                    MessageBox.Show("Pais encontrado", "Correcto");
                    txtNombre.Text = objPaises[i].Nombre;
                    txtPoblacion.Text = objPaises[i].Poblacion.ToString();
                    txtIdioma.Text = objPaises[i].Idioma;
                    txtColor1.Text = objPaises[i].ColBandera[0];
                    txtColor2.Text = objPaises[i].ColBandera[1];
                    txtColor3.Text = objPaises[i].ColBandera[2];
                    i = objPaises.Length;
                    nombre = 1;
                    this.btnImprimir.Enabled = true;
                }
            }
            if(nombre == 0)
            {
                MessageBox.Show("Pais no encontrado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\n" + txtNombre.Text + "\n" + txtPoblacion.Text + "\n" + txtIdioma.Text + "\n" + txtColor1.Text + "\n" + txtColor2.Text + "\n" + txtColor3.Text, "Datos del pais");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
