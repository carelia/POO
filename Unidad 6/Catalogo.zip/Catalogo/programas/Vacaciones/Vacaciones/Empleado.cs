﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vacaciones
{
    class Empleado
    {
        public int Dias(int Años)

        { int dias=0;

            if (Años >= 1 && Años <= 5)
            {
                dias = 5;
            }
            else if
             (Años >= 6 && Años <= 10)
            {
                dias = 10;
            }
            else if
                (Años >= 10 && Años <= 20)
            {
                dias = Años;

            }
            else if
                (Años >= 20)
            {
                dias = (Años - 20) * 2;
                if (dias >= 45)
                {
                    dias = 45;
                }
                }
            return dias;
        }
    }
}
