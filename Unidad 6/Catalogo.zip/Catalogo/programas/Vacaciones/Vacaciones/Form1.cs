﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vacaciones
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            
            int Numero = Convert.ToInt32(txtAños.Text);
            Empleado objVacaciones = new Empleado();
            MessageBox.Show("Los dias de vacaciones son" + objVacaciones.Dias(Numero) + "");

        }
    }
}
