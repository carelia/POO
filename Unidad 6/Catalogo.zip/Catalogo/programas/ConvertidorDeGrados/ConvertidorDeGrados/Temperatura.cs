﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertidorDeGrados
{
    class Temperatura
    {
        public double Grados(double Ncv, double vl) 
        {
            double Gns = 0;
            if (vl == 0)
            {
                Gns = (Ncv - 32) / 1.8;
            }
            else if (vl == 1)
            {
                Gns = (Ncv * 1.8) + 32;
            }

            return Gns;
        }
    }
}