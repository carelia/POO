﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Electricidad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cboContrato.SelectedIndex = 0; //se inicializa el combo con un valor 
        }
        private void btnConsumo_Click(object sender, EventArgs e)
        {
            Recibo objRecibo = new Recibo(); // objeto recibo 
            int Cant = Int32.Parse(txtCantidad.Text);
            int Cons = cboContrato.SelectedIndex;
            double costo=objRecibo.calcularRecibo(Cant, Cons);
            MessageBox.Show("La Cantidad a pagar es: $ " + costo + "");

        }
    }
}
