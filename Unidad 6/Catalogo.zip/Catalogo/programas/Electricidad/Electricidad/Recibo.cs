﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Electricidad
{
    class Recibo
    {
        public double calcularRecibo(int Cant, int Cons) {
            double costo = 0;
            if (Cons == 0)
            {
                if (Cant >= 0 && Cant <= 250)
                {
                    costo = Cant * 0.65;
                }
                else if (Cant > 250 && Cant <= 500)
                {
                    costo = Cant * 0.85;
                }
                else if (Cant > 500 && Cant <= 1200)
                {
                    costo = Cant * 1.5;
                }
                else if (Cant > 1200 && Cant <= 2100)
                {
                    costo = Cant * 2.1;
                }
                else
                {
                    costo = Cant * 3;
                }
            }
            else {
                costo = 5*Cant;
            }
            return costo;
        }
    }
}
