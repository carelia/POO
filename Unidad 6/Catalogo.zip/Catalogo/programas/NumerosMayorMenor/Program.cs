﻿using System;
using System.IO;
namespace NumerosMayorMenor
{
    class Program :numeros
    {
        static void Main(string[] args)
        {
            int[] array = new int[3];
            int menor = 0, mayor = 0;
            TextWriter archivo;

            for (int i = 0; i < array.Length; i++)
            {

                Console.Write("Digite Numero ");
                array[i] = int.Parse(Console.ReadLine());
                if (i == 0)
                {

                    mayor = array[i];
                    menor = array[i];
                }
                else
                {

                    if (array[i] < menor)
                    {

                        menor = array[i];
                    }
                    if (array[i] > mayor)
                    {

                        mayor = array[i];
                    }
                }

            }
            archivo = new StreamWriter("archivo.txt");
            Console.WriteLine("El mayor es " + mayor);
            archivo.WriteLine("El mayor es " + mayor);
            Console.WriteLine("El menor es " + menor);
            archivo.WriteLine("El menor es " + menor);

            archivo.Close();
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
