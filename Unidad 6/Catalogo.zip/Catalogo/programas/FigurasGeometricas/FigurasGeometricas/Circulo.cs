﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    class Circulo : Figura
    {
        public Circulo(float valor1, float valor2, float valor3, float area, float perimetro, float baset) : base(valor1, valor2, valor3, area, perimetro, baset)
        {

        }
        public override string calcularResultado()
        {
            areaobj = Convert.ToSingle(3.1416 * (valor1obj * valor1obj));
            perimetroobj = Convert.ToSingle((2 * 3.1416) * valor1obj);
            return "El area del circulo es:" + areaobj + "\n" + "El perimetro del circulo es:" + perimetroobj + "\n" + "";
            throw new NotImplementedException();
        }
    }
}
