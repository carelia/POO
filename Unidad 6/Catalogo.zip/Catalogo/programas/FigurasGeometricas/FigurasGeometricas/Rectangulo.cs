﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    class Rectangulo:Operacion
    {
        public Rectangulo(float valor1, float valor2, float valor3, float area, float perimetro,float baset) : base(valor1, valor2, valor3, area, perimetro, baset)
        {

        }
        public override string imprimirResultado()
        {
            areaobt = valor1obt * valor2obt;
            perimetroobt = 2 * valor1obt + 2 * valor2obt;
            return "El area del rectangulo es:" + areaobt + "\n" + "El perimetro del rectangulo es:" + perimetroobt + "\n" + "";
            throw new NotImplementedException();
        }
    }
}
