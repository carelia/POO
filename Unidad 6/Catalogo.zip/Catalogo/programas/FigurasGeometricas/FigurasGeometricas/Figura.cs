﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FigurasGeometricas
{
    abstract class Figura
    {
        protected float valor1obj;
        protected float valor2obj;
        protected float valor3obj;
        protected float baseobj;
        protected float areaobj;
        protected float perimetroobj;

        public Figura(float valor1, float valor2, float valor3, float area, float perimetro, float basefig)
        {
            valor1obj = valor1;
            valor2obj = valor2;
            valor3obj = valor3;
            baseobj = basefig;
            areaobj = area;
            perimetroobj = perimetro;
        }
        public abstract string calcularResultado();
    }
}

