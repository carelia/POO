﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    class Vehiculos
    {
        string tipocombustible, color;
        int numllantas, numpuertas, numventanas;

        public Vehiculos()
        {
            tipocombustible = "";
            color = "Blanco";
            numllantas = 0;
            numventanas = 0;
        }
          public string arrancarMotor(string sonido)
        {
            //return "se arranco el motor=+sonido;
           /* string mensaje;
            mensaje = "se arranco el motor " + sonido;
            return mensaje:*/
        }
public string pararmotor(string sonido)
        {
            return "se detuvo el motor" + sonido;
        }

    }
}
