﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpleadosRestaurante
{
    class Mesero : Empleado
    {
        public Mesero(string nombreEmpleadoobt, DateTime fechanacimientoobt, int diastrabajadosobt, float sueldoobt) : base(nombreEmpleadoobt, fechanacimientoobt, diastrabajadosobt, sueldoobt)
        {

        }
        private double propina;
        public double Propina
        {
            set
            {
                propina = value;
            }
            get
            {
                return propina;
            }
        }
        private double sueldocalculado;
        public override string calcularsueldo()
        {
            sueldocalculado = (sueldo * diastrabajados) + propina;
            return "El Mesero " + nombreEmpleado + " con fecha de nacimiento " + fechanacimiento + " \n" + "Su salario semanal fue " + sueldocalculado + "";
            throw new NotImplementedException();
        }

    }
}
