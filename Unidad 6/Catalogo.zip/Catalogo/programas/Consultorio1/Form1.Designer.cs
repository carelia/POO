﻿namespace Consultorio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbEdad = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbEnfermedad = new System.Windows.Forms.ComboBox();
            this.LblEnfermedad = new System.Windows.Forms.Label();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbCantDigestiva = new System.Windows.Forms.Label();
            this.lbCantRespiratoria = new System.Windows.Forms.Label();
            this.lbCantRenal = new System.Windows.Forms.Label();
            this.lbCantCardiaca = new System.Windows.Forms.Label();
            this.lbPromDigestiva = new System.Windows.Forms.Label();
            this.lbPromRespiratoria = new System.Windows.Forms.Label();
            this.lbPromRenal = new System.Windows.Forms.Label();
            this.lbPromCardiaca = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbTotal = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.lbEnfermedadComun = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbEdad
            // 
            this.tbEdad.Location = new System.Drawing.Point(210, 70);
            this.tbEdad.Margin = new System.Windows.Forms.Padding(2);
            this.tbEdad.Name = "tbEdad";
            this.tbEdad.Size = new System.Drawing.Size(92, 20);
            this.tbEdad.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(117, 74);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese edad:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cbEnfermedad
            // 
            this.cbEnfermedad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEnfermedad.FormattingEnabled = true;
            this.cbEnfermedad.Items.AddRange(new object[] {
            "Renal",
            "Cardiaca",
            "Respiratoria",
            "Digestiva"});
            this.cbEnfermedad.Location = new System.Drawing.Point(210, 128);
            this.cbEnfermedad.Margin = new System.Windows.Forms.Padding(2);
            this.cbEnfermedad.Name = "cbEnfermedad";
            this.cbEnfermedad.Size = new System.Drawing.Size(92, 21);
            this.cbEnfermedad.TabIndex = 1;
            this.cbEnfermedad.SelectedIndexChanged += new System.EventHandler(this.CbEnfermedad_SelectedIndexChanged);
            // 
            // LblEnfermedad
            // 
            this.LblEnfermedad.AutoSize = true;
            this.LblEnfermedad.Location = new System.Drawing.Point(9, 128);
            this.LblEnfermedad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblEnfermedad.Name = "LblEnfermedad";
            this.LblEnfermedad.Size = new System.Drawing.Size(180, 13);
            this.LblEnfermedad.TabIndex = 3;
            this.LblEnfermedad.Text = "Selecciona la enfermedad a tratarse:";
            // 
            // btnImprimir
            // 
            this.btnImprimir.Location = new System.Drawing.Point(54, 159);
            this.btnImprimir.Margin = new System.Windows.Forms.Padding(2);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(91, 27);
            this.btnImprimir.TabIndex = 3;
            this.btnImprimir.Text = "Imprimir ";
            this.btnImprimir.UseVisualStyleBackColor = true;
            this.btnImprimir.Click += new System.EventHandler(this.BtnImprimir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 273);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tipo de enfermedad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(131, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Cant. de Personas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(245, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Prom. De Edades";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 345);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cardiaca";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(79, 306);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Renal";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 392);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Respiratoria";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(63, 435);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Digestiva";
            // 
            // lbCantDigestiva
            // 
            this.lbCantDigestiva.AutoSize = true;
            this.lbCantDigestiva.Location = new System.Drawing.Point(157, 435);
            this.lbCantDigestiva.Name = "lbCantDigestiva";
            this.lbCantDigestiva.Size = new System.Drawing.Size(13, 13);
            this.lbCantDigestiva.TabIndex = 15;
            this.lbCantDigestiva.Text = "0";
            // 
            // lbCantRespiratoria
            // 
            this.lbCantRespiratoria.AutoSize = true;
            this.lbCantRespiratoria.Location = new System.Drawing.Point(157, 392);
            this.lbCantRespiratoria.Name = "lbCantRespiratoria";
            this.lbCantRespiratoria.Size = new System.Drawing.Size(13, 13);
            this.lbCantRespiratoria.TabIndex = 14;
            this.lbCantRespiratoria.Text = "0";
            // 
            // lbCantRenal
            // 
            this.lbCantRenal.AutoSize = true;
            this.lbCantRenal.Location = new System.Drawing.Point(157, 306);
            this.lbCantRenal.Name = "lbCantRenal";
            this.lbCantRenal.Size = new System.Drawing.Size(13, 13);
            this.lbCantRenal.TabIndex = 13;
            this.lbCantRenal.Text = "0";
            // 
            // lbCantCardiaca
            // 
            this.lbCantCardiaca.AutoSize = true;
            this.lbCantCardiaca.Location = new System.Drawing.Point(157, 345);
            this.lbCantCardiaca.Name = "lbCantCardiaca";
            this.lbCantCardiaca.Size = new System.Drawing.Size(13, 13);
            this.lbCantCardiaca.TabIndex = 12;
            this.lbCantCardiaca.Text = "0";
            // 
            // lbPromDigestiva
            // 
            this.lbPromDigestiva.AutoSize = true;
            this.lbPromDigestiva.Location = new System.Drawing.Point(270, 435);
            this.lbPromDigestiva.Name = "lbPromDigestiva";
            this.lbPromDigestiva.Size = new System.Drawing.Size(13, 13);
            this.lbPromDigestiva.TabIndex = 19;
            this.lbPromDigestiva.Text = "0";
            // 
            // lbPromRespiratoria
            // 
            this.lbPromRespiratoria.AutoSize = true;
            this.lbPromRespiratoria.Location = new System.Drawing.Point(270, 392);
            this.lbPromRespiratoria.Name = "lbPromRespiratoria";
            this.lbPromRespiratoria.Size = new System.Drawing.Size(13, 13);
            this.lbPromRespiratoria.TabIndex = 18;
            this.lbPromRespiratoria.Text = "0";
            // 
            // lbPromRenal
            // 
            this.lbPromRenal.AutoSize = true;
            this.lbPromRenal.Location = new System.Drawing.Point(270, 306);
            this.lbPromRenal.Name = "lbPromRenal";
            this.lbPromRenal.Size = new System.Drawing.Size(13, 13);
            this.lbPromRenal.TabIndex = 17;
            this.lbPromRenal.Text = "0";
            // 
            // lbPromCardiaca
            // 
            this.lbPromCardiaca.AutoSize = true;
            this.lbPromCardiaca.Location = new System.Drawing.Point(270, 345);
            this.lbPromCardiaca.Name = "lbPromCardiaca";
            this.lbPromCardiaca.Size = new System.Drawing.Size(13, 13);
            this.lbPromCardiaca.TabIndex = 16;
            this.lbPromCardiaca.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 240);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(151, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "No. De pasientes Registrados:";
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Location = new System.Drawing.Point(167, 240);
            this.lbTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(13, 13);
            this.lbTotal.TabIndex = 21;
            this.lbTotal.Text = "0";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(210, 159);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 27);
            this.button1.TabIndex = 2;
            this.button1.Text = "Guardar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 491);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(188, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "El Tipo de enfermedad mas comun es:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // lbEnfermedadComun
            // 
            this.lbEnfermedadComun.AutoSize = true;
            this.lbEnfermedadComun.Location = new System.Drawing.Point(203, 491);
            this.lbEnfermedadComun.Name = "lbEnfermedadComun";
            this.lbEnfermedadComun.Size = new System.Drawing.Size(14, 13);
            this.lbEnfermedadComun.TabIndex = 23;
            this.lbEnfermedadComun.Text = "X";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Consultorio.Properties.Resources.consultorio_medico;
            this.pictureBox1.Location = new System.Drawing.Point(413, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(401, 506);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 530);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbEnfermedadComun);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbTotal);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbPromDigestiva);
            this.Controls.Add(this.lbPromRespiratoria);
            this.Controls.Add(this.lbPromRenal);
            this.Controls.Add(this.lbPromCardiaca);
            this.Controls.Add(this.lbCantDigestiva);
            this.Controls.Add(this.lbCantRespiratoria);
            this.Controls.Add(this.lbCantRenal);
            this.Controls.Add(this.lbCantCardiaca);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnImprimir);
            this.Controls.Add(this.LblEnfermedad);
            this.Controls.Add(this.cbEnfermedad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbEdad);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbEdad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbEnfermedad;
        private System.Windows.Forms.Label LblEnfermedad;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbCantDigestiva;
        private System.Windows.Forms.Label lbCantRespiratoria;
        private System.Windows.Forms.Label lbCantRenal;
        private System.Windows.Forms.Label lbCantCardiaca;
        private System.Windows.Forms.Label lbPromDigestiva;
        private System.Windows.Forms.Label lbPromRespiratoria;
        private System.Windows.Forms.Label lbPromRenal;
        private System.Windows.Forms.Label lbPromCardiaca;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbTotal;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbEnfermedadComun;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

