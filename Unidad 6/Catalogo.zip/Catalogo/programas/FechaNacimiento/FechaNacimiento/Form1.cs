﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FechaNacimiento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Persona objPersona = new Persona(); //Se crea el objeto correspondiente a la clase Persona 
            DateTime Fecha =dtpFecha.Value; //obtiene unicamente el valor de la fecha que selecciono del datetimepicker y lo guarda en una variable de tipo Datatime
          String edad=  objPersona.Edad(Fecha); //se usa el metodo Edad de la clase  enviando el valor de la fecha de nacimiento, el resultado que retorne se guardara en una variable tipo string  
            MessageBox.Show(edad); // se muestra si es mayor o menor de edad ,mediante una ventana emergente 
        }
    }
}
