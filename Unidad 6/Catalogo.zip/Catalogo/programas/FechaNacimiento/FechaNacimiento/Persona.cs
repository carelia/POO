﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FechaNacimiento
{
    class Persona
    {
        public String Edad(DateTime Fechaobt) { //se crea un metodo, este le debe llegar el dato de la fecha seleccionada por el tipo datetime y es un string porque retornara unicamente el mensaje si es mayor o menor de edad
            DateTime Fechaactual = DateTime.Today; //se obtiene la fecha actual y se guarda en una variable tipo datetime llamada fecha actual 
            TimeSpan edad = Fechaactual - Fechaobt; // calcula la diferencia entre dos fechas (dia, mes, año) y el resultado se guarda en una variable tipo timeSpan que separa los valores en años 
            double edad2 =(edad.TotalDays / 365.25); //el valor calculo se divide entre los 365 dias con 25 minutos que tiene un año y se guarda en una variable de tipo doble que esta arroja la edad, con tantos meses y dias 
            String calculo; //se crea una variable para almacenar si es menor o mayor de edad 
            if (edad2 >= 18) // si el valor de la diferencia de edades es mayor o igual a 18 el usuario es mayor de edad
            {
                calculo = "Es mayor de edad"; //se guarda en la variable calculo el mensaje 
            }
            else // sino es mayor o igual a 18 entonces es menor de edad 
            {
                calculo = "Es menor de edad"; //se guarda el mensaje de que es menor de edad en la variable calculo  
            }
            return calculo; // retornamos la cadena de texto 
        }
    }
}
