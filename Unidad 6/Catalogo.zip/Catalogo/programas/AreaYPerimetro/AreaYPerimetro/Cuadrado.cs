﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaYPerimetro
{
    class Cuadrado
    {
        public Tuple<double,double> AreaPerimetro(double Lado)// metodo retorna multiples valores de un solo tipo
        {
            double Area = 0;
            Area = Lado * Lado;
            double Perimetro = 0;
            Perimetro = Lado * 4;
            return new Tuple<double, double>(Area, Perimetro);// retorna el valor
         }
    }
}
