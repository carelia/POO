﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Pais
    {
        public string Nombre;
        public string Poblacion;
        public string Idioma;
        public string[] Colores = new string[3]; //Arreglo para guardar los 3 colores
    }
}
