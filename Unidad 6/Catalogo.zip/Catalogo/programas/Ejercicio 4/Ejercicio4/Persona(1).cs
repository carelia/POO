﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4
{
    public class Persona
    {
        public string Nombre;
        public string FechaNacimiento;
        public string Curp;
        public string Telefono;
        public string Email;
    }
}
