﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3
{
    public partial class FormAlumno : Form
    {
        //Crear objeto alumno
       
      public  Alumno alumno = new Alumno();
            
        public FormAlumno()
        {
            InitializeComponent();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            //Validar que no haya campos vacios
            if (CamposVacios()) { MessageBox.Show("No puede dejar campos vacios"); return; }

            //Validar que tenga por lo menos una materia agregada.
           if( dgvMaterias.Rows.Count <= 1) { MessageBox.Show("Debe Registrar por lo menos una materia"); return; }

            alumno.Nombre = tbNombre.Text;
            alumno.FechaNacimiento = tbFecha.Text;
            alumno.Curp = tbCurp.Text;
            alumno.Telefono = tbTelefono.Text;
            alumno.Email = tbEmail.Text;
            alumno.NoControl = tbNocontrol.Text;
            alumno.Carrera = tbCarrera.Text;
            //Pasar las materias y calificaciones del data gridview al objeto
            for (int i = 0; i < dgvMaterias.Rows.Count - 1; i++)
            {
                alumno.MateriasCalif[i, 0] = dgvMaterias.Rows[i].Cells[0].Value.ToString();
                alumno.MateriasCalif[i, 1] = dgvMaterias.Rows[i].Cells[1].Value.ToString();
            }
            MessageBox.Show("Datos guardados correctamente");
           DialogResult = DialogResult.OK;
            this.Close();
            
        }
        public bool CamposVacios() //Verificar que no haya campos vacios
        {
            if (tbNombre.Text == "" || tbFecha.Text == "" || tbCurp.Text == "" || tbTelefono.Text == "" || tbEmail.Text == "" || tbNocontrol.Text == "" || tbCarrera.Text == "") return true;
            else return false;
        }

        private void BtnAgregarMateria_Click(object sender, EventArgs e)
        {
            //Validar que no esten vacios los campos
            if (tbMateria.Text == "" || tbCalif.Text == "") { MessageBox.Show("No puede dejar campos vacios"); return; }
            //Validar que esten como maximo 8 materias
            if (dgvMaterias.Rows.Count > 6) { MessageBox.Show("Solo se pueden temer maximo 6 materias"); return; }
            DataGridViewRow fila = new DataGridViewRow();
            fila.CreateCells(dgvMaterias);
            fila.Cells[0].Value = tbMateria.Text;
            fila.Cells[1].Value = tbCalif.Text;
            dgvMaterias.Rows.Add(fila);
            tbCalif.Text = "";
            tbMateria.Text = "";
        }
    }
    //Crear clase alumno que hereda los atributos de la clase persona
    public class Alumno: Persona
    {
        
        public string NoControl;
        public string Carrera;
        public string[,] MateriasCalif = new string [6,2]; //Arreglo para guardar las materias y calificaciones

    }
}
