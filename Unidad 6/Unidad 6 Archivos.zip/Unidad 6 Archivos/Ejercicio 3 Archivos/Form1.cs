﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3
{
    public partial class Form1 : Form
    {
        Alumno alumno = new Alumno();
        
        Docente docente = new Docente();
        public Form1()
        {
            InitializeComponent();
            alumno.Nombre = "";
            docente.Nombre = "";
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            FormAlumno fmalumno = new FormAlumno();
           DialogResult res = fmalumno.ShowDialog();
            if(res == DialogResult.OK)
            {//PAra pasar el objeto creado en el formulario mostrado
                alumno = fmalumno.alumno;
            }
        }

  
        private void BtnImpralu_Click(object sender, EventArgs e)
        {
            if(alumno.Nombre == "") { MessageBox.Show("Aun no se han capturado los datos del alumno"); return; }
            DatosAlumno datos = new DatosAlumno(alumno);
            datos.Show();
        }

     

        private void btnDocente_Click_1(object sender, EventArgs e)
        {
            FormDocente fmdocente = new FormDocente();
            DialogResult res = fmdocente.ShowDialog();
            if (res == DialogResult.OK)
            {
                docente = fmdocente.docente;
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            if (docente.Nombre == "") { MessageBox.Show("Aun no se han capturado los datos del Docente"); return; }
            DatosDocente datos = new DatosDocente(docente);
            datos.Show();
        }
    }
}
