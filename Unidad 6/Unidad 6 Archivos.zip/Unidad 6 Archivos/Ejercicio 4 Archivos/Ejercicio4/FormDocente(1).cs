﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4
{
    public partial class FormDocente : Form
    {
        public Docente docente = new Docente();
        public FormDocente()
        {
            InitializeComponent();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            //Validar que no haya campos vacios
            if (CamposVacios()) { MessageBox.Show("No puede dejar campos vacios"); return; }

            //Validar que tenga por lo menos una materia agregada.
            if (dgvMaterias.Rows.Count <= 1) { MessageBox.Show("Debe Registrar por lo menos una materia"); return; }
            docente.Nombre = tbNombre.Text;
            docente.FechaNacimiento = tbFecha.Text;
            docente.Curp = tbCurp.Text;
            docente.Telefono = tbTelefono.Text;
            docente.Email = tbEmail.Text;
            docente.NoMaestro = tbNomaestro.Text;
            docente.Sueldo = tbSueldo.Text;
            //Pasar las materias del datagrid al objeto
            for (int i = 0; i < dgvMaterias.Rows.Count - 1; i++)
            {
                docente.Materias[i] = dgvMaterias.Rows[i].Cells[0].Value.ToString();
            }
            MessageBox.Show("Datos guardados correctamente");
            DialogResult = DialogResult.OK;
            this.Close();
        }
        public bool CamposVacios() //Verificar que no haya campos vacios
        {
            if (tbNombre.Text == "" || tbFecha.Text == "" || tbCurp.Text == "" || tbTelefono.Text == "" || tbEmail.Text == "" || tbNomaestro.Text == "" || tbSueldo.Text == "") return true;
            else return false;
        }

        private void BtnAgregarMateria_Click(object sender, EventArgs e)
        {
            //Validar que no esten vacios los campos
            if (tbMateria.Text == "") { MessageBox.Show("No puede dejar campos vacios"); return; }
            //Validar que esten como maximo 8 materias
            if (dgvMaterias.Rows.Count > 5) { MessageBox.Show("Solo se pueden temer maximo 5 materias"); return; }
            DataGridViewRow fila = new DataGridViewRow();
            fila.CreateCells(dgvMaterias);
            fila.Cells[0].Value = tbMateria.Text;
            dgvMaterias.Rows.Add(fila);
            tbMateria.Text = "";
        }

     
    }
    //Clase Docente
    public class Docente : Persona
    {
        public string NoMaestro;
        public string Sueldo;
        public string[] Materias = new string[5];
    }
}
