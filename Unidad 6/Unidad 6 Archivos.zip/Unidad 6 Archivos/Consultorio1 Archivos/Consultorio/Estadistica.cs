﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Consultorio
{
    public class Estadistica
    {

        public string[,] EdadEnfermedad = new string[2, 80];
        public int[] TotalPorEnfermedad; //Cantidad de personas
        public double[] PromedioPorEnfermedad;//Promedio de edades por enfermedad
       public string EnfermedadComun;
        
        
        public void Calcular(int total)
        {
            string aux = "lol";
            PromedioPorEnfermedad = new double[4];
            TotalPorEnfermedad = new int[4];
            for (int i = 0; i < total; i++)
            {
                aux = EdadEnfermedad[0, i];
                switch (EdadEnfermedad[0, i])
                {
                    case "Renal": TotalPorEnfermedad[0]++; PromedioPorEnfermedad[0] += Convert.ToInt32(EdadEnfermedad[1, i]); break;
                    case "Cardiaca": TotalPorEnfermedad[1]++; PromedioPorEnfermedad[1] += Convert.ToInt32(EdadEnfermedad[1, i]); break;
                    case "Respiratoria": TotalPorEnfermedad[2]++; PromedioPorEnfermedad[2] += Convert.ToInt32(EdadEnfermedad[1, i]); break;
                    case "Digestiva": TotalPorEnfermedad[3]++; PromedioPorEnfermedad[3] += Convert.ToInt32(EdadEnfermedad[1, i]); break;
                }
            }

            for (int i = 0; i < 4; i++)
            {
                if(TotalPorEnfermedad[i] != 0)
                PromedioPorEnfermedad[i] = (int)PromedioPorEnfermedad[i]/TotalPorEnfermedad[i];

                if(TotalPorEnfermedad[i] >= TotalPorEnfermedad[0] && TotalPorEnfermedad[i] >= TotalPorEnfermedad[1] && TotalPorEnfermedad[i] >= TotalPorEnfermedad[2] && TotalPorEnfermedad[i] >= TotalPorEnfermedad[3])// si es mayor o igual a todos
                {
                    switch (i)
                    {
                        case 0: EnfermedadComun = "Renal"; break;
                        case 1: EnfermedadComun = "Cardiaca"; break;
                        case 2: EnfermedadComun = "Respiratoria"; break;
                        case 3: EnfermedadComun = "Digestiva"; break;
                    }
                }
            }

            
        }

    }
}
